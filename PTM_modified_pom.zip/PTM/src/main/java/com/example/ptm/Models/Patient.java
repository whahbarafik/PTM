package com.example.ptm.Models;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table
@Entity
public class Patient extends Abstract{
    public String Nom;
    public String Prenom;
    private int Cin;
    public String Email;
    public int Age;
    public String GroupeSanguin;
    public String Allergie;
    public String Covid;
    public int Tel;
}
