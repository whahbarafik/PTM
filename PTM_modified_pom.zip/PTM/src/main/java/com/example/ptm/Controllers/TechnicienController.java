package com.example.ptm.Controllers;

import com.example.ptm.Models.Patient;
import com.example.ptm.Models.Technicien;
import com.example.ptm.Repository.PatientRepository;
import com.example.ptm.Services.TechnicienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class TechnicienController {
    @Autowired
    private TechnicienService technicienService;
    /*get all */
    @GetMapping(value = "/Technicien")
    public List<Technicien> listTechnicien(){
        return technicienService.findAll();
    }
    /*find by id*/
    @GetMapping(value="/Technicien/{id}")
    public Optional<Technicien> AfficherTechnicien(@PathVariable("id") Long id){
        return technicienService.findById(id);
    }
    /*post */
    @PostMapping(value = "/Technicien")
    public void addPatient(@RequestBody Technicien t){
        technicienService.save(t);
    }
    /*put */
    @PutMapping(value = "/Technicien/Update/{id}")
    public void updateTechnicien(@RequestBody Technicien t,@PathVariable("id") Long id){
        t.setId(id);
        technicienService.save(t);
    }
    /* delete */
    @DeleteMapping(value = "/Technicien/Delete/{id}")
    public boolean deleteTechnicien(@PathVariable("id") Long id){
        technicienService.deleteById(id);
        return true;
    }
}

