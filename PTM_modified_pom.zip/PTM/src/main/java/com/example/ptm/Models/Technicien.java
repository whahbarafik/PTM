package com.example.ptm.Models;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table
@Entity
public class Technicien extends Abstract{

}
