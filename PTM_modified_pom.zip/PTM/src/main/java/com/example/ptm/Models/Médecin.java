package com.example.ptm.Models;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table
public class Médecin extends Abstract{
    public String Nom;
    public String Prenom;
    public String Email;
    public String Spetialite;
    public int Tel;
    public String Adresse;
}
