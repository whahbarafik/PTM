package com.example.ptm.Models;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class Abstract {
    @Id
    @GeneratedValue
    private Long Id;
    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }
}
