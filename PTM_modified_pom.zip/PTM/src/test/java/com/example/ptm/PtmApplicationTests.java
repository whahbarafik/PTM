package com.example.ptm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PtmApplicationTests {

    @Test
    void contextLoads() {
    }

}
